extern void gauss_init(void);
