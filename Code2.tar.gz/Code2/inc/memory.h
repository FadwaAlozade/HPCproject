extern void alloc(void);
extern void loc_alloc(void);
extern void dealloc(void);
