extern double *hFil, *uFil, *vFil, *hPhy, *uPhy, *vPhy;
extern int nb_steps, size_x, size_y;
