#include <stdio.h>

FILE *create_file(void);
void export_step(FILE*, int);
void finalize_export(FILE*);
