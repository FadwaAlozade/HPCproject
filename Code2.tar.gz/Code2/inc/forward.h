void forward(int NP, int rang);
